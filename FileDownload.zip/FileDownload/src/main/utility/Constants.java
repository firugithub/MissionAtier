package main.utility;

public class Constants {

	public static final String DOWNLOAD_LOCATION = "/home/utkarshgoel/Documents/";
	
	public static final int   DEFAULT_READ_TIMEOUT = 5000;
	
	public static final String FILE_TYPE = ".txt";
		
}
