package main.utility;

public enum Protocols {

	HTTP,FTP,SFTP,HTTPS;
}
