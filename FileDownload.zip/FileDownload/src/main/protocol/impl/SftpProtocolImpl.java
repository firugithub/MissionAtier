package main.protocol.impl;

import main.model.FileDownload;
import main.protocol.IProtocol;

public class SftpProtocolImpl implements IProtocol{

	@Override
	public void download(String source, FileDownload file) {
		// TODO Auto-generated method stub
		
	}

}
